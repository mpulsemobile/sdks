//
//  MpulseFramework.h
//  MpulseFramework
//
//  Created by Heena Dhawan on 10/04/18.
//  Copyright © 2018 mPulse. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MpulseFramework.
FOUNDATION_EXPORT double MpulseFrameworkVersionNumber;

//! Project version string for MpulseFramework.
FOUNDATION_EXPORT const unsigned char MpulseFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MpulseFramework/PublicHeader.h>


